# Frontend Architecture Document Generator

This folder contains a reproducible generator for leadership-grade frontend architecture documentation.

## Outputs

Running the generator creates the following files in this folder:

- `DocMind_Frontend_Architecture_Handbook.docx`
- `frontend_system_architecture.png`
- `frontend_component_layers.png`
- `frontend_user_flows.jpg`

## Run

```powershell
cd C:\Users\raman\eclipse-workspace\docmind-backend\docs\frontend_architecture
python -m pip install -r requirements.txt
python generate_frontend_architecture_docs.py
```

## Notes

- The document is formatted for Microsoft Word with heading hierarchy, tables, and embedded diagrams.
- Diagram files are generated in PNG and JPEG formats for direct use in decks, reports, and wiki pages.
