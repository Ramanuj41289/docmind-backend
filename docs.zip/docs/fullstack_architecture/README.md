# DocMind Full Stack Architecture Document Generator

This package generates a Microsoft Word document and image diagrams for the end-to-end DocMind full stack architecture.

## Generated outputs

- `DocMind_Fullstack_End_to_End_Architecture.docx`
- `docmind_fullstack_end_to_end_flow.png`
- `docmind_fullstack_layered_architecture.png`
- `docmind_request_response_sequence.jpg`

## Run

```powershell
cd C:\Users\raman\eclipse-workspace\docmind-backend\docs\fullstack_architecture
python -m pip install -r requirements.txt
python generate_fullstack_e2e_docs.py
```

## Source basis

The content is aligned with:

- `docs/DocMind_Enterprise_Database_Architecture_Specification.md`
- `docs/architecture-diagrams.md`
- Frontend implementation under `frontend/docmind-frontend/src`

